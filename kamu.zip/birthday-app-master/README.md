

# Setups

1)Install Python 3 

2)
```
cd birthday-app
```

3) To run the app

```
python -m http.server 8000
```

visit http://localhost:8000 or http://127.0.0.1:8000 in your browser.

